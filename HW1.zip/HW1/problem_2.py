import numpy as np
import math
import random
import pandas as pd
from copy import deepcopy

np.random.seed(0)

# Global variables
P_AA = 0.95*0.95
P_TT = 0.05*0.05
P_AT = 1 - (P_AA + P_TT)

def compute_posterior(L_AA, L_TT, L_AT):
    marginal = np.exp(L_AA) * P_AA + np.exp(L_TT) * P_TT + np.exp(L_AT) * P_AT

    pos_AA = ( np.exp(L_AA) * P_AA ) / marginal
    pos_TT = ( np.exp(L_TT) * P_TT ) / marginal
    pos_AT = ( np.exp(L_AT) * P_AT ) / marginal
    
    return pos_AA, pos_TT, pos_AT

def posterior(data):
    L_AA, L_TT, L_AT = 0.0, 0.0, 0.0
    for i in range(len(data)):
        if data.loc[i, 'observations'] == 'A':
            _d = 1 - data.loc[i, 'probability_of_error']
        else:
            _d = data.loc[i, 'probability_of_error']

        L_AA = L_AA + np.log(_d)
        L_TT = L_TT + np.log(1 - _d)
        L_AT = L_AT + np.log(0.5)
    
    pos_AA, pos_TT, pos_AT = compute_posterior(L_AA, L_TT, L_AT)

    return [pos_AA, pos_TT, pos_AT]



def construct_histograms(entire_data, samples, fig_name):
    all_pos = []
    for i in range(1000):
        data = entire_data.sample(n=samples, replace=True, ignore_index=False)
        data.reset_index(inplace=True)
        pos_ = posterior(data)

        all_pos.append(pos_)

    all_pos = np.array(all_pos)

    print("Statistics -> ", "Mean: ", np.mean(all_pos, axis=0), " , Std: ", np.std(all_pos, axis=0), " , Median: ", np.median(all_pos, axis=0))
    
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(1, 3, sharey=True, tight_layout=False, figsize=(20,10))

    n_bins = 50
    axs[0].hist(all_pos[:, 0], bins=n_bins)
    axs[1].hist(all_pos[:, 1], bins=n_bins)
    axs[2].hist(all_pos[:, 2], bins=n_bins)

    fig.supxlabel('Posterior Probabilities')
    fig.supylabel('Frequency')

    plt.savefig(fig_name)


if __name__ == "__main__":
    entire_data = pd.read_csv("reads.tsv", sep = "\t")



    # Solution to 2.b)
    data = deepcopy(entire_data)
    print("Posterior probability of the three possible genotypes, given the entire data: ", posterior(data))



    # Solution to 2.c)
    data = entire_data.sample(n=5, replace=True, random_state=0, ignore_index=False)
    data.reset_index(inplace=True)
    print("Posterior probability of the three possible genotypes, given 5 data points: ", posterior(data))



    # Solution to 2.d)
    fig_name = "problem_2d.png"
    construct_histograms(entire_data, 5, fig_name)



    # Solution to 2.e)
    fig_name = "problem_2e.png"
    construct_histograms(entire_data, 50, fig_name)
import numpy as np
import math
import random
import pandas as pd
from copy import deepcopy

np.random.seed(0)

# Global variables
BASES = ['A','C','G','T']
P_AA = 0.95*0.95
P_TT = 0.05*0.05
P_AT = 1 - (P_AA + P_TT)


def compute_posterior(L_AA, L_TT, L_AT):
    marginal = np.exp(L_AA) * P_AA + np.exp(L_TT) * P_TT + np.exp(L_AT) * P_AT

    pos_AA = ( np.exp(L_AA) * P_AA ) / marginal
    pos_TT = ( np.exp(L_TT) * P_TT ) / marginal
    pos_AT = ( np.exp(L_AT) * P_AT ) / marginal
    
    return pos_AA, pos_TT, pos_AT

def posterior(data):
    L_AA, L_TT, L_AT = 0.0, 0.0, 0.0
    for i in range(len(data)):
        if data.loc[i, 'observations'] == 'A':
            _d = 1 - data.loc[i, 'probability_of_error']
        else:
            _d = data.loc[i, 'probability_of_error']

        L_AA = L_AA + np.log(_d)
        L_TT = L_TT + np.log(1 - _d)
        L_AT = L_AT + np.log(0.5)
    
    pos_AA, pos_TT, pos_AT = compute_posterior(L_AA, L_TT, L_AT)

    return [pos_AA, pos_TT, pos_AT]


def plot_histogram(all_pos):
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(1, 3, sharey=True, tight_layout=False, figsize=(20,10))

    n_bins = 20
    axs[0].hist(all_pos[:, 0], bins=n_bins)
    axs[1].hist(all_pos[:, 1], bins=n_bins)
    axs[2].hist(all_pos[:, 2], bins=n_bins)

    fig.supxlabel('Posterior Probabilities')
    fig.supylabel('Frequency')

    plt.savefig("Problem_3d.png")


def simulation(errors, transitions):
    all_pos = []
    for i in range(1000):
        read_list, prob_errors_list = [], []
        for j in range(20):
            prob = random.random()
            _e_rate = random.choice(errors)
            if prob > _e_rate:
                read_list.append("A")
            else:
                read_list.append("T")
            prob_errors_list.append(_e_rate)
        
        assert len(read_list) == 20
        data = pd.DataFrame({"observations" : read_list, "probability_of_error" : prob_errors_list})
        posterior_probs = posterior(data)
        all_pos.append(posterior_probs)

    all_pos = np.array(all_pos)
    plot_histogram(all_pos)



if __name__ == "__main__":
    errors = pd.read_csv("errors.tsv", sep = "\t", header=None)
    errors = list(errors[0])
    transitions = pd.read_csv("transitions.tsv", sep = "\t", header=None)
    simulation(errors, transitions)
import numpy as np
import math


def get_prob(N, e):
    a = 0.095 * math.pow(0.5, N)
    b = 0.95*0.95*math.pow(e, N-70)*math.pow(1-e,70) + 0.0025*math.pow(1-e,N-70)*math.pow(e,70) + 0.095*math.pow(0.5,N)
    return a/(b + 1e-8)

def obtain_N(e):
    for i in range(5000):
        prob = get_prob(i, e)
        if prob >= 0.99 - 1e-6:
            return i
    
    return "No feasible value found in first 500 naturals"

if __name__ == "__main__":
    # different values of e
    for e in list(np.linspace(0.01, 0.99, 100)):
        N = obtain_N(e)
        print("N , e : ", N, " , ", e)

# Libraries used
Numpy, pandas, scipy, matplotlib, seaborn

# Running the code
To run the code simply use 
```
python code.py
```

# Figures
Figures for all the questions are saved in "png" format with appropriate naming
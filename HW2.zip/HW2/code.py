import numpy as np
import pandas as pd
from scipy.stats import multinomial
import matplotlib.pyplot as plt
import seaborn as sns
from copy import deepcopy


class GenerativeModel:
    def __init__(self):
        self.p_file = pd.read_table("p.tsv")
        self.p_values = list(self.p_file[self.p_file.columns[0]])
        self.q_file = pd.read_table("q.tsv")
        self.q_values = list(self.q_file[self.q_file.columns[0]])

    # Problem 1a
    def prob_1a(self):
        N_ = [15000, 30000, 150000]
        raw_counts = []
        
        for i in range(3):
            raw_counts.append(multinomial.rvs(n=N_[i], p=self.p_values,random_state=91))
        raw_counts = np.array(raw_counts)

        df = {'N=15000': raw_counts[0], 'N=150000': raw_counts[2]}
        df = pd.DataFrame(df)
        
        sns.scatterplot(x="N=15000", y="N=150000", data=df)
        plt.savefig("prob_1a.png")
        plt.close()

        self.raw_counts_1a = raw_counts.T

    
    # Problem 1b
    def prob_1b(self):
        _a = self.raw_counts_1a + 1
        b = np.divide(_a, np.power( np.prod(_a, axis=1), 1/3 ).reshape(-1, 1) )
        self.normalized_1b = b
        self.median_1b = np.median(self.normalized_1b, axis=0)
        print("Median computed for problem 1c = ", self.median_1b)
        
    # Problem 1c
    def prob_1c(self):
        nbins = 50
        fig, axs = plt.subplots(1, 2, sharey=True, tight_layout=False, figsize=(12, 8))
        axs[0].hist(self.normalized_1b[:, 0], bins=nbins)
        axs[0].set_xlabel("N=15000")
        axs[0].set_ylabel("Count")

        axs[1].hist(self.normalized_1b[:, 2], bins=nbins)
        axs[1].set_xlabel("N=150000")
        
        plt.savefig("prob_1c_histograms.png")
        plt.close()

        df = {'N=15000': self.normalized_1b[:, 0], 'N=150000': self.normalized_1b[:, 2]}
        df = pd.DataFrame(df)
        
        sns.scatterplot(x="N=15000", y="N=150000", data=df)
        plt.savefig("prob_1c_scatterplot.png")
        plt.close()

    
    # Problem 1d
    def prob_1d(self):
        self.Y_1d = np.divide(self.raw_counts_1a, self.median_1b.reshape(-1, 3))
        df = {'N=15000': self.Y_1d[:, 0], 'N=150000': self.Y_1d[:, 2]}
        df = pd.DataFrame(df)
        
        sns.scatterplot(x="N=15000", y="N=150000", data=df)
        plt.savefig("prob_1d_scatterplot.png")
        plt.close()


    # Problem 1e
    def prob_1e(self):
        N_ = [1e6, 1e6, 1e6]
        raw_counts = []
        
        for i in range(3):
            raw_counts.append(multinomial.rvs(n=N_[i], p=self.p_values,random_state=i))
        raw_counts = np.array(raw_counts)

        self.raw_counts_1e = raw_counts.T

        _a = self.raw_counts_1e + 1
        b = np.divide(_a, np.power( np.prod(_a, axis=1), 1/3 ).reshape(-1, 1) )
        self.normalized_1e = b
        self.median_1e = np.median(self.normalized_1e, axis=0)
        print("Median computed for problem 1e = ", self.median_1e)

        df = {'N=1e6_first_sample': self.normalized_1e[:, 0], 'N=1e6_third_sample': self.normalized_1e[:, 2]}
        df = pd.DataFrame(df)
        
        sns.scatterplot(x="N=1e6_first_sample", y="N=1e6_third_sample", data=df)
        plt.savefig("prob_1e_scatterplot.png")
        plt.close()


    # Problem 1f
    def prob_1f(self):
        N_ = [1e6, 1e6, 1e6]
        raw_counts = []
        
        for i in range(3):
            raw_counts.append(multinomial.rvs(n=N_[i], p=self.q_values,random_state=i))
        raw_counts = np.array(raw_counts)

        self.raw_counts_1f = raw_counts.T

        _a = self.raw_counts_1f + 1
        b = np.divide(_a, np.power( np.prod(_a, axis=1), 1/3 ).reshape(-1, 1) )
        self.normalized_1f = b
        self.median_1f = np.median(self.normalized_1f, axis=0)
        print("Median computed for problem 1f = ", self.median_1f)

        nbins = 50
        fig, axs = plt.subplots(1, 3, sharey=True, tight_layout=False, figsize=(18, 8))
        axs[0].hist(self.normalized_1f[:, 0], bins=nbins)
        axs[0].set_xlabel("N=1e6_first_sample")
        axs[0].set_ylabel("Count")

        axs[1].hist(self.normalized_1f[:, 1], bins=nbins)
        axs[1].set_xlabel("N=1e6_second_sample")

        axs[2].hist(self.normalized_1f[:, 2], bins=nbins)
        axs[2].set_xlabel("N=1e6_third_sample")
        
        plt.savefig("prob_1f_histograms.png")
        plt.close()

        df = {'N=1e6_first_sample': self.normalized_1f[:, 0], 'N=1e6_third_sample': self.normalized_1f[:, 2]}
        df = pd.DataFrame(df)
        
        sns.scatterplot(x="N=1e6_first_sample", y="N=1e6_third_sample", data=df)
        plt.savefig("prob_1f_scatterplot.png")
        plt.close()

    
    # problem 1g
    def prob_1g(self):
        self.raw_counts_1g = np.concatenate((self.raw_counts_1e, self.raw_counts_1f), axis=1)
        
        _a = self.raw_counts_1g + 1
        _dd = np.exp(np.sum( np.log(_a), axis=1) / 6)
        b = np.divide(_a, _dd.reshape(-1, 1) )
        self.normalized_1g = b
        self.median_1g = np.median(self.normalized_1g, axis=0)
        print("Median computed for problem 1g = ", self.median_1g)

        print(self.normalized_1g)

        nbins = 50
        fig, axs = plt.subplots(2, 3, sharey=False, tight_layout=False, figsize=(18, 16))
        axs[0, 0].hist(self.normalized_1g[:, 0], bins=nbins)
        axs[0, 0].set_xlabel("N=first_sample")
        axs[0, 0].set_ylabel("Count")

        axs[0, 1].hist(self.normalized_1g[:, 1], bins=nbins)
        axs[0, 1].set_xlabel("N=second_sample")

        axs[0, 2].hist(self.normalized_1g[:, 2], bins=nbins)
        axs[0, 2].set_xlabel("N=third_sample")

        axs[1, 0].hist(self.normalized_1g[:, 3], bins=nbins)
        axs[1, 0].set_xlabel("N=fourth_sample")
        axs[1, 0].set_ylabel("Count")

        axs[1, 1].hist(self.normalized_1g[:, 4], bins=nbins)
        axs[1, 1].set_xlabel("N=fifth_sample")

        axs[1, 2].hist(self.normalized_1g[:, 5], bins=nbins)
        axs[1, 2].set_xlabel("N=sixth_sample")
        
        plt.savefig("prob_1g_histograms.png")
        plt.close()


        self.Y_1g = np.divide(self.raw_counts_1g, self.median_1g.reshape(-1, 6))
        df = {'First_sample': self.Y_1g[:, 0], 'Sixth_sample': self.Y_1g[:, 5]}
        df = pd.DataFrame(df)
        
        sns.scatterplot(x="First_sample", y="Sixth_sample", data=df)
        plt.savefig("prob_1g_scatterplot.png")
        plt.close()

    
    def compare_p_q(self):
        nbins = 50
        fig, axs = plt.subplots(1, 2, sharey=True, tight_layout=False, figsize=(12, 8))
        axs[0].hist(self.p_values, bins=nbins)
        axs[0].set_xlabel("P Values")
        axs[0].set_ylabel("Count")

        axs[1].hist(self.q_values, bins=nbins)
        axs[1].set_xlabel("Q values")

        plt.savefig("P_and_Q_histograms.png")
        plt.close()



if __name__ == "__main__":
    model = GenerativeModel()

    model.prob_1a()

    model.prob_1b()
    
    model.prob_1c()

    model.prob_1d()

    model.prob_1e()

    model.prob_1f()

    model.prob_1g()

    model.compare_p_q()
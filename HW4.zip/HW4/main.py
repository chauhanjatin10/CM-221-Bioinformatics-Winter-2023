import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from scipy.spatial.distance import squareform, pdist



class ImplementTSNE:
    def __init__(self):
        self.data = pd.read_csv("problem1.tsv", sep='\t', header=None).to_numpy()
        
    def problem_1a(self, sigma):
        dist = squareform(pdist(self.data))
        a = np.divide( np.power(dist, 2), 2*sigma.reshape(-1, 1) )
        b = np.exp(-a)
        c = np.ones(dist.shape[0]) - np.eye(dist.shape[0])
        probs =  b * c
        probs_1a = np.divide(probs, np.sum(probs, axis=1).reshape(-1, 1))
        return probs_1a
        
    def problem_1b(self, sigma):
        p_vals = self.problem_1a(sigma)
        probs_1b = (p_vals + p_vals.T) / (2*p_vals.shape[0])
        return probs_1b

    def problem_1c(self):
        for sg in [1, 0.1, 10, 100]:
            sigma = np.array([sg]*self.data.shape[0])
            vals = self.problem_1b(sigma)
            a = vals[:, 0]
            a = a / np.max(a)

            plt.scatter(self.data[:, 0], self.data[:, 1], c=a, cmap='viridis')
            plt.colorbar()
            plt.savefig("prob_1c_sigma_value_{}.png".format(sg))
            plt.close()

    def problem_1d(self):
        dist = np.power(squareform(pdist(self.data)), 2)
        a = 1 + dist
        b = np.divide(1, a)
        c = np.ones(dist.shape[0]) - np.eye(dist.shape[0])
        probs =  b * c
        probs = probs / np.sum(probs)
        return probs

    def problem_1e(self):
        vals = self.problem_1d()
        a = vals[:, 0]
        a = a / np.max(a)

        plt.scatter(self.data[:, 0], self.data[:, 1], c=a, cmap='coolwarm')
        plt.colorbar()
        plt.savefig("prob_1e.png")
        plt.close()

    def problem_1f(self, dist_a, dist_b):
        mask = np.logical_and(dist_a > 0, dist_b > 0)
        return np.sum(dist_a[mask] * np.log(dist_a[mask] / dist_b[mask]))

    def problem_1g(self):
        for sg in [0.1, 1, 100]:
            sigma = np.array([sg]*self.data.shape[0])
            a = self.problem_1b(sigma)
            b = self.problem_1d()
            kl_ = self.problem_1f(a, b)
            print("KL div with sigma^2 {0} = {1}".format(sg, kl_))


if __name__ == "__main__":
    tsne = ImplementTSNE()
    tsne.problem_1c()
    tsne.problem_1d()
    tsne.problem_1e()
    tsne.problem_1g()
    
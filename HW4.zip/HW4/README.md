# Libraries used
Numpy, pandas, scipy, matplotlib

# Running the code
To run the code simply use 
```
python main.py
```

# Figures
Figures for all the questions are saved in "png" format with appropriate naming